var avatarName;
var nounsList = [];

var privateGameButton = document.querySelector('#buttonLoginCreatePrivate');
privateGameButton.click();
window.setTimeout(function() {
  avatarName = document.querySelectorAll('div.avatarContainer + div.name')[1].innerText;
  nounsList.push(avatarName);
  console.log(nounsList);
}, 3000);