var canvas = document.querySelector('#gameCanvas');
var ctx = canvas.getContext('2d');
var red=document.querySelector('#red');
var green=document.querySelector('#green');
var blue=document.querySelector('#blue');
var black=document.querySelector('#black');

red.addEventListener('click',function(){
  ctx.fillStyle='red';
});
green.addEventListener('click',function(){
  ctx.fillStyle='green';
});
blue.addEventListener('click',function(){
  ctx.fillStyle='blue';
});
black.addEventListener('click',function(){
  ctx.fillStyle='black';
});

function fillStyle(color){
  ctx.fillStyle=color;
}

canvasSize();
window.addEventListener('resize', canvasSize);
function canvasSize(){
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  ctx.fillStyle='white';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle='black';
}


canvas.addEventListener('mousemove', draw)

function draw(e){
  console.log(e.clientX, e.clientY);
  ctx.beginPath();
  ctx.moveTo(e.clientX, e.clientY);
  ctx.arc(e.clientX, e.clientY, 5, 0, Math.PI * 2, true);
  ctx.fill();
}
