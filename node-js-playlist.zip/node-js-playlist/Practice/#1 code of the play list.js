console.log("Hello Saif, You are learning Node.js!");

setTimeout(function(){
    console.log("Three seconds \n have passed!");

},3000);