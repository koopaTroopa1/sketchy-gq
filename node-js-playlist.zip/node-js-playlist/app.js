const express = require('express');

var app = express();
app.set('view engine', 'ejs');


app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html');
});

app.get('/just_a_dot', function(req, res) {
  res.sendFile(__dirname + '/dot.html');
});

app.get('/profiles/:id', function(req, res) {
  res.render('profile', {
    id: req.params.id
  });
});


app.listen(3000);