var evalForm = document.getElementById('evaluation');
var submitButton = document.getElementById('submitButton');

submitButton.addEventListener('click', function() {
  evalForm.submit();
});
